CS 143 Project 1B
804762497, 004189106

In this project the work was split up as follows:
Aadil worked on create.sql, query.php and readme.txt
Zegao worked on create.sql, load.sql, queries.sql, violate.sql, and team.txt
